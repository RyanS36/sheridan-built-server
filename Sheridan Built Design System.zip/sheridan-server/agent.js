// agent.js — Hourly Claude AI analysis + suggestion generation

const Anthropic = require('@anthropic-ai/sdk');
const { v4: uuid } = require('uuid');
const store = require('./store');
const { notify } = require('./notify');

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SITE_CONTEXT = `
You are the background AI marketing agent for "Sheridan Built Ltd.", a Toronto carpentry contracting company.

COMPANY:
- Owner: Tyler Sheridan
- Phone: 647-402-5913
- Email: sheridanbuiltltd@gmail.com
- Location: Toronto, Ontario & GTA
- Founded: 2025
- Services: Trim & Millwork, Kitchen Renovations, Deck & Framing, Custom Built-Ins, Door & Window Trim, Finishing Carpentry

WEBSITE SECTIONS:
- Hero: "Built With Pride. Finished With Precision." — CTA buttons: "Get a Free Quote" + "View Our Work"
- Services: 6 service cards on off-white background
- Process: 4-step flow (Reach Out → Free Quote → We Work → Guaranteed Results)
- Portfolio: 6 project cards with category filters (Kitchen, Millwork, Trim, Deck)
- CTA Strip: Gold banner "Your project deserves craftsmanship that lasts." 
- Testimonials: 3 five-star reviews (Sarah M., James R., Linda K.)
- About: Tyler Sheridan headshot area + 5 trust points + stats
- Contact: Quote request form + phone/email

BRAND:
- Colors: Gold #F0A500, Charcoal #252422, Cream #F5EDD8, Off-White #FAF8F3
- Tone: Direct, confident, craftsman pride, local and personal
- Target: Toronto homeowners, residential, quality-focused

YOUR TASK:
Analyze the current date/season and suggest ONE specific, high-impact improvement to help the site convert more visitors into leads.

Current time: ${new Date().toLocaleString('en-CA', { timeZone: 'America/Toronto', weekday:'long', month:'long', day:'numeric', year:'numeric', hour:'numeric', minute:'2-digit' })} ET

Consider: seasonal relevance (spring = deck/renovation season, fall = interior work, winter = planning), 
day-of-week (Mon = start of week urgency, Fri = weekend project planning),
time-of-day (morning = action-oriented, evening = research mode).

Focus areas:
- copy: Sharper, more persuasive text
- trust: Social proof, credentials, guarantees, urgency
- cta: Better call-to-action text or placement
- seasonal: Time/season-relevant promotion or message
- content: Missing information that would help visitors decide

Respond with ONLY a valid JSON object, no markdown:
{
  "category": "copy" | "trust" | "cta" | "seasonal" | "content",
  "section": "hero" | "services" | "process" | "portfolio" | "cta_strip" | "testimonials" | "about" | "contact" | "header",
  "suggestion": "2-3 sentence description of what to change and why",
  "change_type": "text" | "badge" | "cta" | "banner",
  "original": "current text/element (approximate)",
  "proposed": "the new text or element (concise, ready to use)",
  "rationale": "one sentence on expected conversion impact"
}
`.trim();

async function runAnalysis() {
  console.log(`[agent] Running analysis at ${new Date().toISOString()}`);

  try {
    const message = await client.messages.create({
      model: 'claude-haiku-4-5',
      max_tokens: 512,
      messages: [{ role: 'user', content: SITE_CONTEXT }],
    });

    const raw = message.content[0].text;
    console.log('[agent] Raw response:', raw);

    // Extract JSON
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON found in response');

    const data = JSON.parse(match[0]);

    // Validate required fields
    const required = ['category', 'section', 'suggestion', 'change_type', 'original', 'proposed', 'rationale'];
    for (const field of required) {
      if (!data[field]) throw new Error(`Missing field: ${field}`);
    }

    const suggestion = {
      id: uuid(),
      ...data,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    store.add(suggestion);
    console.log(`[agent] Suggestion created: ${suggestion.id} (${suggestion.category} / ${suggestion.section})`);

    // Notify
    await notify(suggestion);

    return suggestion;
  } catch (err) {
    console.error('[agent] Analysis failed:', err.message);
    return null;
  }
}

module.exports = { runAnalysis };
