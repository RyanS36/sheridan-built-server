// server.js — Sheridan Built Ltd. main server
// Express + hourly cron + API endpoints + static site

require('dotenv').config();
const express = require('express');
const cron = require('node-cron');
const path = require('path');
const store = require('./store');
const { runAnalysis } = require('./agent');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── API: get pending suggestions ─────────────────────────
app.get('/api/suggestions', (req, res) => {
  res.json(store.getPending());
});

// ── API: get all suggestions (for dashboard) ─────────────
app.get('/api/suggestions/all', (req, res) => {
  res.json(store.getAll());
});

// ── API: accept a suggestion ─────────────────────────────
app.post('/api/suggestions/:id/accept', (req, res) => {
  const item = store.updateStatus(req.params.id, 'accepted');
  if (!item) return res.status(404).json({ error: 'Not found' });
  console.log(`[server] Suggestion ${req.params.id} accepted`);
  res.json(item);
});

// ── API: dismiss a suggestion ────────────────────────────
app.post('/api/suggestions/:id/dismiss', (req, res) => {
  const item = store.updateStatus(req.params.id, 'dismissed');
  if (!item) return res.status(404).json({ error: 'Not found' });
  console.log(`[server] Suggestion ${req.params.id} dismissed`);
  res.json(item);
});

// ── API: trigger analysis manually ───────────────────────
app.post('/api/agent/run', async (req, res) => {
  const key = req.headers['x-agent-key'];
  if (key !== process.env.AGENT_SECRET) return res.status(401).json({ error: 'Unauthorized' });
  console.log('[server] Manual analysis triggered');
  const result = await runAnalysis();
  res.json(result || { error: 'Analysis failed' });
});

// ── API: agent status ─────────────────────────────────────
app.get('/api/agent/status', (req, res) => {
  const all = store.getAll();
  res.json({
    running: true,
    schedule: 'Every hour (on the hour)',
    totalSuggestions: all.length,
    pending: all.filter(s => s.status === 'pending').length,
    accepted: all.filter(s => s.status === 'accepted').length,
    dismissed: all.filter(s => s.status === 'dismissed').length,
    lastRun: all[0]?.createdAt || null,
    nextRun: getNextHour(),
    notifyEmail: process.env.NOTIFY_EMAIL || 'ryansheridan06@gmail.com',
    notifyPhone: process.env.NOTIFY_PHONE || '+14167281209',
  });
});

// ── Dashboard route ───────────────────────────────────────
app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// ── Cron: run every hour on the hour ─────────────────────
cron.schedule('0 * * * *', async () => {
  console.log('[cron] Hourly analysis starting...');
  await runAnalysis();
}, { timezone: 'America/Toronto' });

// ── Health check ──────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime() }));

// ── Start ─────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🏠 Sheridan Built Server running on port ${PORT}`);
  console.log(`   Site:      http://localhost:${PORT}`);
  console.log(`   Dashboard: http://localhost:${PORT}/dashboard`);
  console.log(`   Agent:     Hourly cron active (America/Toronto)\n`);
});

function getNextHour() {
  const d = new Date();
  d.setHours(d.getHours() + 1, 0, 0, 0);
  return d.toISOString();
}
