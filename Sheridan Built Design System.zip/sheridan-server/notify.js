// notify.js — SMS (Twilio) + Email (nodemailer) notifications

const nodemailer = require('nodemailer');

// ── Email ──────────────────────────────────────────────────
const emailTransport = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD, // Gmail App Password (not login password)
  },
});

async function sendEmail(suggestion) {
  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
    console.log('[notify] Email env vars not set — skipping email');
    return;
  }
  const categoryEmoji = { copy:'✍️', trust:'🛡️', cta:'🎯', seasonal:'🍂', content:'📋' };
  const emoji = categoryEmoji[suggestion.category] || '💡';

  await emailTransport.sendMail({
    from: `"Sheridan Built Agent" <${process.env.GMAIL_USER}>`,
    to: process.env.NOTIFY_EMAIL || 'ryansheridan06@gmail.com',
    subject: `${emoji} Agent Suggestion: ${suggestion.category.toUpperCase()} — ${suggestion.section}`,
    html: `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;border:1px solid #eee;">
        <div style="background:#252422;padding:24px 28px;display:flex;align-items:center;gap:14px;">
          <img src="https://i.imgur.com/placeholder.png" style="height:40px;" alt="Sheridan Built"/>
          <div>
            <div style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#F0A500;font-weight:700;">AI Agent Suggestion</div>
            <div style="font-size:18px;font-weight:700;color:#FAF8F3;margin-top:2px;">Sheridan Built Ltd.</div>
          </div>
        </div>
        <div style="padding:28px;">
          <div style="background:#FDF1CC;border-left:4px solid #F0A500;padding:14px 18px;border-radius:4px;margin-bottom:24px;">
            <div style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#C88A00;margin-bottom:6px;">${suggestion.category} · ${suggestion.section}</div>
            <p style="font-size:16px;color:#252422;line-height:1.6;margin:0;">${suggestion.suggestion}</p>
          </div>
          <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
            <tr style="background:#f9f9f9;"><td style="padding:10px 14px;font-size:13px;font-weight:700;color:#666;width:100px;">Current</td><td style="padding:10px 14px;font-size:14px;color:#333;">"${suggestion.original}"</td></tr>
            <tr><td style="padding:10px 14px;font-size:13px;font-weight:700;color:#C88A00;">Proposed</td><td style="padding:10px 14px;font-size:14px;color:#252422;font-weight:600;">"${suggestion.proposed}"</td></tr>
            <tr style="background:#f9f9f9;"><td style="padding:10px 14px;font-size:13px;font-weight:700;color:#666;">Impact</td><td style="padding:10px 14px;font-size:13px;color:#3D7A4E;">${suggestion.rationale}</td></tr>
          </table>
          <div style="display:flex;gap:12px;">
            <a href="${process.env.SITE_URL || 'http://localhost:3000'}/dashboard?action=accept&id=${suggestion.id}" style="display:inline-block;background:#F0A500;color:#0F0D0A;padding:12px 28px;border-radius:4px;font-weight:700;font-size:13px;letter-spacing:1px;text-transform:uppercase;text-decoration:none;">✓ Apply Change</a>
            <a href="${process.env.SITE_URL || 'http://localhost:3000'}/dashboard?action=dismiss&id=${suggestion.id}" style="display:inline-block;background:transparent;color:#666;padding:12px 22px;border-radius:4px;font-size:13px;text-decoration:none;border:1px solid #ddd;">Dismiss</a>
          </div>
          <p style="font-size:12px;color:#aaa;margin-top:20px;">Generated ${new Date(suggestion.createdAt).toLocaleString('en-CA', { timeZone:'America/Toronto' })} ET · <a href="${process.env.SITE_URL || 'http://localhost:3000'}/dashboard" style="color:#F0A500;">View Dashboard</a></p>
        </div>
      </div>
    `,
  });
  console.log(`[notify] Email sent for suggestion ${suggestion.id}`);
}

// ── SMS via Twilio ─────────────────────────────────────────
async function sendSMS(suggestion) {
  if (!process.env.TWILIO_SID || !process.env.TWILIO_TOKEN || !process.env.TWILIO_FROM) {
    console.log('[notify] Twilio env vars not set — skipping SMS');
    return;
  }
  const twilio = require('twilio')(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);
  const body = [
    `🏠 Sheridan Built Agent`,
    `Suggestion (${suggestion.category}): ${suggestion.suggestion.slice(0, 80)}...`,
    `Proposed: "${suggestion.proposed}"`,
    `Review: ${process.env.SITE_URL || 'http://localhost:3000'}/dashboard`,
  ].join('\n');

  await twilio.messages.create({
    body,
    from: process.env.TWILIO_FROM,
    to: process.env.NOTIFY_PHONE || '+14167281209',
  });
  console.log(`[notify] SMS sent for suggestion ${suggestion.id}`);
}

async function notify(suggestion) {
  const errors = [];
  try { await sendEmail(suggestion); } catch (e) { errors.push(`Email: ${e.message}`); console.error('[notify] Email error:', e.message); }
  try { await sendSMS(suggestion); }   catch (e) { errors.push(`SMS: ${e.message}`);   console.error('[notify] SMS error:', e.message); }
  if (errors.length) console.warn('[notify] Some notifications failed:', errors);
}

module.exports = { notify };
