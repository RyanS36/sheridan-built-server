// store.js — Suggestion persistence (flat JSON file)
// Keeps the last 100 suggestions in suggestions.json

const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'suggestions.json');

function load() {
  try {
    if (fs.existsSync(FILE)) return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {}
  return [];
}

function save(data) {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

function getAll() {
  return load();
}

function getPending() {
  return load().filter(s => s.status === 'pending');
}

function add(suggestion) {
  const list = load();
  list.unshift(suggestion);
  // Keep last 100
  save(list.slice(0, 100));
  return suggestion;
}

function updateStatus(id, status) {
  const list = load();
  const item = list.find(s => s.id === id);
  if (!item) return null;
  item.status = status;
  item.updatedAt = new Date().toISOString();
  save(list);
  return item;
}

module.exports = { getAll, getPending, add, updateStatus };
