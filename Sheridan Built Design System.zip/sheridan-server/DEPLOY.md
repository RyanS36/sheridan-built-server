# Sheridan Built — 24/7 Server Deploy Guide

## What this is
A Node.js/Express server that:
- Serves your Sheridan Built website publicly (sheridanbuilt.up.railway.app or your own domain)
- Runs a Claude AI agent **every hour**, automatically
- Sends you an **SMS** (Twilio) + **email** when it has a suggestion
- Gives you a private **dashboard** to review and apply suggestions

---

## STEP 1 — Get your API keys

### 1a. Claude API Key (Anthropic)
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Click **API Keys** → **Create Key**
3. Copy it — you'll need it in Step 3

### 1b. Gmail App Password (for email notifications)
1. Make sure your Gmail has 2FA enabled
2. Go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Create a new App Password → name it "Sheridan Agent"
4. Copy the 16-character password

### 1c. Twilio (for SMS — optional but recommended)
1. Sign up free at [twilio.com](https://twilio.com)
2. Get a free trial phone number (Canadian numbers available)
3. Copy your **Account SID**, **Auth Token**, and **Phone Number**
4. Free trial gives ~$15 credit (~150 text messages)

---

## STEP 2 — Add the website to this folder

Copy your `Sheridan Built Website.html` into `sheridan-server/public/` and rename it `index.html`:

```
sheridan-server/
└── public/
    ├── index.html        ← your website goes here
    └── dashboard.html    ← already there
```

---

## STEP 3 — Deploy to Railway

### 3a. Create a free Railway account
Go to [railway.app](https://railway.app) and sign up with GitHub.

### 3b. Upload this folder to GitHub
1. Create a new repo on github.com (call it `sheridan-built-server`)
2. Upload everything in `sheridan-server/` to that repo
   - You can drag-and-drop files on github.com
3. Make sure `.env.example` is included but **never** `.env`

### 3c. Deploy from GitHub
1. In Railway: **New Project** → **Deploy from GitHub repo**
2. Select your `sheridan-built-server` repo
3. Railway auto-detects Node.js and deploys

### 3d. Set environment variables
In Railway dashboard → your project → **Variables** tab:

| Variable | Value |
|---|---|
| `ANTHROPIC_API_KEY` | Your Claude API key |
| `AGENT_SECRET` | Any strong password (e.g. `SheridanAgent2025!`) |
| `GMAIL_USER` | ryansheridan06@gmail.com |
| `GMAIL_APP_PASSWORD` | Your Gmail App Password |
| `TWILIO_SID` | Your Twilio Account SID |
| `TWILIO_TOKEN` | Your Twilio Auth Token |
| `TWILIO_FROM` | Your Twilio phone number (e.g. +16471234567) |
| `NOTIFY_EMAIL` | ryansheridan06@gmail.com |
| `NOTIFY_PHONE` | +14167281209 |
| `SITE_URL` | https://your-app.up.railway.app *(set after first deploy)* |

Click **Deploy** after setting variables.

---

## STEP 4 — Your live URLs

After deploy, Railway gives you a URL like:
```
https://sheridan-built-server-production.up.railway.app
```

| URL | Purpose |
|---|---|
| `/` | Your live website |
| `/dashboard` | Agent dashboard (review suggestions) |
| `/health` | Server health check |
| `/api/suggestions` | Pending suggestions (JSON) |
| `/api/agent/status` | Agent status (JSON) |

---

## STEP 5 — Test it

### Test the agent manually:
In the dashboard, click **▶ Run Now** and enter your `AGENT_SECRET`.
You should get:
- A new suggestion card in the dashboard
- A text message to +14167281209
- An email to ryansheridan06@gmail.com

### Check logs:
Railway dashboard → your project → **Logs** tab

---

## Cost estimate

| Service | Cost |
|---|---|
| Railway Hobby plan | $5/month (includes ~$5 compute credit — free for small apps) |
| Anthropic API (haiku) | ~$0.002 per analysis × 24/day = ~$1.50/month |
| Twilio SMS | ~$0.01/SMS × 24/day = ~$7.20/month (or use free trial credit) |
| Gmail | Free |
| **Total** | **~$8–14/month** |

**To reduce cost:** Change agent to run every 3 hours instead of hourly:
In `server.js`, change `'0 * * * *'` to `'0 */3 * * *'`

---

## Custom domain (optional)

1. In Railway: your project → **Settings** → **Custom Domain**
2. Enter your domain (e.g. `sheridanbuilt.ca`)
3. Add the CNAME record in your DNS provider
4. Railway handles SSL automatically

---

## Troubleshooting

**No SMS received?**
- Check Twilio trial accounts require a verified number
- Go to twilio.com → verify your +1 416-728-1209

**No email received?**
- Check spam folder
- Make sure Gmail App Password is correct (not your login password)
- Try: `node -e "require('./notify').notify({category:'test',section:'test',suggestion:'test',original:'a',proposed:'b',rationale:'c',id:'test-1',createdAt:new Date().toISOString()})"`

**Agent not running?**
- Check Railway logs for `[cron]` entries
- Test manually with **▶ Run Now** in dashboard
